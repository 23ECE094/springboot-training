package com.example.Course_Registration_System;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CourseRegistrationSystemApplicationTests {

	@Test
	void contextLoads() {
	}

}
