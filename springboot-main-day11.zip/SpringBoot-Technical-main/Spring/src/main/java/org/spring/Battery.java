package org.spring;

public class Battery implements Vehicle {

    public void move() {
        System.out.println("Battery Get Started");
    }
}
