package com.example.FirstSpringBoot;

public interface Writer {
    void write();
}
