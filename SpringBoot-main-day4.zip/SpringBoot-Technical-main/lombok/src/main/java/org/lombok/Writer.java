package org.lombok;

import org.springframework.stereotype.Component;

@Component
public interface Writer {
    void exam();
}
