package org.spring;

public interface Vehicle {
    void move();
}

