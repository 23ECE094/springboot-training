package com.example.FirstApi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FirstApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
