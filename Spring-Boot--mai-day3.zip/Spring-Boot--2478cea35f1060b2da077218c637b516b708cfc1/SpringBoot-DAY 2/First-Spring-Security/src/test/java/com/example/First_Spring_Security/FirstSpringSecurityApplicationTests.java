package com.example.First_Spring_Security;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FirstSpringSecurityApplicationTests {

	@Test
	void contextLoads() {
	}

}
