package com.example.CrudDemo.Model;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class StudentModel {
    private int roll_no;
    private String Name;
    private String Technology;


}
