package com.example.First_JPA;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FirstJpaApplicationTests {

	@Test
	void contextLoads() {
	}

}
