package org.spring;

public class Engine implements Vehicle{
   /* public Engine() {
        System.out.println("Get Created");
    }*/
    public void move()
    {
        System.out.println( "Engine Get Started" );
    }

}
