package com.example.democrud.model;

import lombok.AllArgsConstructor;
import lombok.Data;
@AllArgsConstructor

@Data

public class Student {
    private int rollno;
    private String name;
    private String technology;


}

