package org.example;

public interface Writer {
    void writing();
}
